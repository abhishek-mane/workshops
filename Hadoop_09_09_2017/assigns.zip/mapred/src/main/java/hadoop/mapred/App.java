package hadoop.mapred;

import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class App {

	public static class Map extends Mapper<LongWritable, Text, IntWritable, Text> {

		private Text word = new Text();
		private static String userId;

		public void map(LongWritable key, Text value, Mapper<LongWritable, Text, IntWritable, Text>.Context context)
				throws IOException, InterruptedException {

			if (userId == null) {
				Configuration conf = context.getConfiguration();
				userId = conf.get("userId");
			}

			StringTokenizer tokenizer = new StringTokenizer(value.toString(), ",");
			if (Integer.parseInt(tokenizer.nextToken()) == Integer.parseInt(userId)) {

				word.set(tokenizer.nextToken());
				int hitCount = Integer.parseInt(tokenizer.nextToken());
				context.write(new IntWritable(hitCount), word);
			}
		}
	}

	public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
		public void reduce(IntWritable key, Iterable<Text> values,
				Reducer<IntWritable, Text, IntWritable, Text>.Context context)
				throws IOException, InterruptedException {

			for (Text val : values) {
				context.write(key, val);
			}
		}
	}

	public static void main(String[] args) throws Exception {

		Scanner s = new Scanner(System.in);
		System.out.println("\n----------------------------- WELCOME TO MAPREDUCE JOB -----------------------------");

		System.out.println("\nMapReduce Job Starting...");

		System.out.print("\nEnter user id : ");
		int userId = s.nextInt();
		s.close();
		System.out.println();

		Configuration conf = new Configuration();
		conf.set("userId", "" + userId);

		Job job = Job.getInstance(conf, "ebooks Job");
		job.setJarByClass(App.class);

		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);

		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
