package sqoop;

import java.util.Scanner;
import com.cloudera.sqoop.*;
import com.cloudera.sqoop.tool.*;

public class App {
	
	public static Scanner s = new Scanner(System.in);
	private static SqoopOptions options;
	
	private static String dataBase = null;
	private static String tableName = null;
	private static String DBURL = null;
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";
	private static String IMPORT_DIR = null;		// will be used in case of import
	private static String EXPORT_FILE = null;		// will be used in case of export
	
	public static void initialize(String db, String table){
		
		dataBase = db;
		tableName = table;
		
		DBURL = "jdbc:mysql://192.168.31.200:3306/"+dataBase;
		options = new SqoopOptions(DBURL,table);
		options.setUsername(USERNAME);
		options.setPassword(PASSWORD);
		options.setFieldsTerminatedBy(',');
		options.setLinesTerminatedBy('\n');
	}
	
	// IMPORTING.. i.e mysql table to hdfs file
	public static void mysqlToHdsf(){
		
		System.out.println("--------------------- IMPORT OPERATION ---------------------");
		
		System.out.println("Note that output directory must not exist.");
		System.out.print("\nEnter direcory where output will be stored (eg, /home/abhi/Desktop/out) : ");
		IMPORT_DIR = s.next();
		
		options.setTargetDir(IMPORT_DIR);
		
		@SuppressWarnings("deprecation")
		ImportTool it = new ImportTool();
		int retVal = it.run(options);
		
		if(retVal == 0){
			System.out.println("SUCCESSFULLY Imported...");
		}
		else{
			System.out.println("ERROR");
		}
	}
	
	// EXPORTING... i.e hdfs file to mysql table
	public static void hdfsToMysql(){
		
		System.out.println("--------------------- IMPORT OPERATION ---------------------");
		
		System.out.println("delete all entries from mysql table '"+tableName+"' before exporting. else Exception may cause.");
		System.out.print("\ndone ? (y/n) : ");
		String ch = s.next();
		if(ch.equalsIgnoreCase("y"));
		else{
			System.out.println("Export operation aborted by user.."); return;
		}
		
		System.out.print("\nEnter path to the data to be exported to mysql (eg, /home/abhi/Desktop/in/data) : ");
		EXPORT_FILE = s.next();
		
		String []columns = {"book_id", "book_title", "book_author"};
		
		options.setExportDir(EXPORT_FILE);
		options.setDbOutputColumns(columns);
		options.setUpdateMode(SqoopOptions.UpdateMode.AllowInsert);		
		
		ExportTool it = new ExportTool();
		int retVal = it.run(options);
		
		if(retVal == 0){
			System.out.println("SUCCESSFULLY Exported...");
		}
		else{
			System.out.println("ERROR");
		}
	}
	
	public static void main(String []args)
	{
		String db, table;
		int choice;
		
		System.out.println("Note : Database & Table must be already present in MySQL.");
		System.out.print("\nEnter name of the database : ");
		db = s.next();
		System.out.print("\nEnter name of the table : ");
		table = s.next();
			
		initialize(db, table);
		
		do{	
			System.out.println("================================ SQOOP ================================");
			System.out.println("1. MySQL to HDFS [IMPORT]");
			System.out.println("2. HDFS to MySQL [EXPORT]");
			System.out.println("3. Exit");
			System.out.print("\nEnter choice : ");
			choice = s.nextInt();
			
			switch(choice){
				case 1 : mysqlToHdsf(); break;
				case 2 : hdfsToMysql(); break;
				case 3 : System.exit(0);
				
				default: System.out.println("Invalid choice... Please try again...");
			}
		}while(choice != 3);
	}
	
}
