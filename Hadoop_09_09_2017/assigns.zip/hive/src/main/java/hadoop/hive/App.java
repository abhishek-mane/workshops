package hadoop.hive;

import java.sql.*;
import java.util.Scanner;

public class App{
	public static Scanner s = new Scanner(System.in);
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection con=null;
	private static Statement stmt=null;
	
	private static String dataBase=null;
	private static String tableName=null;
	
	public static void decorate(){
		System.out.println("\n==================================================================================================");
	}
	
	public static void initialize() throws ClassNotFoundException, SQLException{
		
		Class.forName(driverName);
		con = DriverManager.getConnection("jdbc:hive2://192.168.31.200:10000/", "", "");
		stmt = con.createStatement();
	}
	
	public static void closeConnection(){
		try{
			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static void createDatabase(String db) throws SQLException{
		
		dataBase = db;
		
		stmt.executeUpdate("create database "+dataBase);
		System.out.println("###$$$ Database "+dataBase+" successfully created...");
		
		stmt.executeUpdate("use "+dataBase);
	}
	
	public static void createTable(String tb, String dataPath) throws SQLException{
		tableName = tb;
		String query = "create table " +tableName+ "("	+
							"id int,"						+
							"title varchar(100),"			+
							"author varchar(100),"			+
							"publication varchar(100),"		+
							"price int)"					+
							"row format delimited "			+
							"fields terminated by ',' "		+
							"lines terminated by '\n'";
			
		stmt.executeUpdate(query);
		System.out.println("###$$$ Table "+tableName+" successfully created...");
			
		query = "load data local inpath '"+ dataPath +"' into table "+tableName;
		stmt.executeUpdate(query);
	}
	
	public static void showAllBooks() throws SQLException{
		
		decorate();
		String query = "select * from "+tableName;
		System.out.println("\n###$$$ Running : '"+query+"'");
		ResultSet res = stmt.executeQuery(query);
		
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("ID\tTitle\tAuthor\tPublication\tPrice");
		System.out.println("--------------------------------------------------------------------------------------------------");
		while (res.next()) {
			System.out.print("\n"+res.getInt(1)+", "+res.getString(2)+", "+res.getString(3)+", "+res.getString(4)+", "+res.getInt(5));
		}
		decorate();
		System.out.println("\n");
	}
	
	public static void prices() throws SQLException{
		
		decorate();
		String query = "select max(price), min(price), avg(price) from "+tableName;
		System.out.println("\n###$$$ Running : '"+query+"'");
		ResultSet res = stmt.executeQuery(query);
		
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("Max\tmin\tAvg");
		System.out.println("--------------------------------------------------------------------------------------------------");
		while (res.next()) {
			System.out.print("\n"+res.getInt(1)+"\t"+res.getInt(2)+"\t"+res.getInt(3));
		}
		decorate();
		System.out.println("\n");
	}

	public static void cost() throws SQLException{
		decorate();
		String query = "select sum(price) from "+tableName;
		System.out.println("\n###$$$ Running : '"+query+"'");
		ResultSet res = stmt.executeQuery(query);
		
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("Total cost of books in library");
		System.out.println("--------------------------------------------------------------------------------------------------");
		while (res.next()) {
			System.out.print("\n"+res.getInt(1));
		}
		decorate();
		System.out.println("\n");
	}
	
	public static void search() throws SQLException{
		
		System.out.print("\n\nEnter name of book : ");
		String book = s.next();
		
		String query = "select * from "+tableName+" where title like '%"+book+"%'";
		System.out.println("\n###$$$ Running : '"+query+"'");
		ResultSet res = stmt.executeQuery(query);
		
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("\nMatched Results...");
		System.out.println("--------------------------------------------------------------------------------------------------");
		while (res.next()) {
			System.out.print("\n"+res.getInt(1)+", "+res.getString(2)+", "+res.getString(3)+", "+res.getString(4)+", "+res.getInt(5));
		}
		decorate();
		System.out.println("\n");
	}
	
	public static void main(String []args){

		String dataBase, tableName, dataPath;
		
		System.out.print("\nEnter database name to be created : ");
		dataBase = s.next();
		
		System.out.print("\nEnter table name to be created : ");
		tableName = s.next();
		
		System.out.print("\nEnter path to the data file (for loading data into table) : ");
		dataPath = s.next();
		
		try{
			initialize();
			createDatabase(dataBase);
			createTable(tableName,dataPath);
			
			int choice;
			do{
				System.out.println("---------------------------- Digital Library ----------------------------");
				System.out.println("1. show all books.");
				System.out.println("2. show max, min & avg book prices.");
				System.out.println("3. show total cost of all books available.");
				System.out.println("4. search book by name.");
				System.out.println("5. Exit.");
				System.out.print("\nEnter choice : ");
				choice = s.nextInt();
				
				switch(choice){
					case 1 : showAllBooks(); break;
					case 2 : prices(); break;
					case 3 : cost(); break;
					case 4 : search(); break;
					case 5 : s.close(); System.exit(0);
					default: System.out.println("Enter valid choice !!!");
				}
			}while(true);
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}
}